# nixos-thinkpad-dwm

Minimal NixOS 26.05 + X11 + dwm configuration for the ThinkPad. The intended model is **GitHub as the source of truth**, with safe test-before-switch updates on the laptop.

## Repository layout

Keep the repository flat:

```text
nixos-thinkpad-dwm/
├── flake.nix
├── flake.lock                 # generate/keep this on the laptop and commit it
├── README.md
├── system/
│   ├── configuration.nix
│   ├── audio.nix
│   └── hardware-configuration.nix   # copy the laptop's existing file and commit it
└── user/
    ├── apps.nix
    ├── home.nix
    ├── theme.nix
    ├── scripts/
    └── suckless/
```

Do **not** keep another `nixos-thinkpad/` directory inside the GitHub repository.

## One-time migration from the current nested checkout

Your tested laptop checkout currently has the flake inside `~/nixos-thinkpad-dwm/nixos-thinkpad/`. Before replacing anything, keep a backup of that working directory.

The safe migration is:

1. Put the contents of this GitHub-ready folder at the **root** of `~/nixos-thinkpad-dwm`.
2. Keep your laptop's existing `system/hardware-configuration.nix`.
3. Keep your already-generated `flake.lock` (or run `nix flake lock` once if it is absent).
4. Keep/copy your preferred wallpaper if desired, then run `set-wallpaper /path/to/image.jpg` once.
5. From the repository root run `nix flake check` and `sudo nixos-rebuild test --flake .#thinkpad`.
6. Only after the test is good, commit and push the files.

## Normal GitHub update workflow

Once this revision has been switched successfully, two commands are installed in `~/.local/bin`.

### Pull and test

```sh
nix-sync
```

`nix-sync`:

- refuses to overwrite uncommitted local edits;
- runs `git pull --ff-only`;
- runs `nix flake check`;
- runs `sudo nixos-rebuild test --flake .#thinkpad`.

The new revision is active for testing, but it is **not** made the next boot default.

### Make the tested revision permanent

```sh
nix-apply
```

That performs another flake check and then:

```sh
sudo nixos-rebuild switch --flake .#thinkpad
```

This is intentionally not a blind automatic `switch`: one bad GitHub commit should not silently become the next boot configuration.

If the checkout ever lives somewhere else, set `NIXOS_CONFIG_REPO` to its path before running those commands.

## Wallpaper

`set-wallpaper` copies the selected image to:

```text
~/Pictures/wallpaper.jpg
```

It then:

1. applies it with `feh`;
2. generates terminal colors with Wallust;
3. updates `~/.Xresources`;
4. signals existing `st` terminals to reload colors.

At X startup, `.xinitrc` now restores `~/Pictures/wallpaper.jpg` automatically if the file exists. This means your chosen Renaissance/classical wallpaper survives reboot without keeping an absolute path into an old Sway repository.

`Super+W` remains bound to `set-wallpaper`.

## Bluetooth

`blueman-manager` needs the Blueman applet to be present on D-Bus. `.xinitrc` now starts:

```sh
blueman-applet &
```

so `Super+Shift+M` can open the Bluetooth manager after login.

## qutebrowser ad blocking

qutebrowser does not run the uBlock Origin extension itself. This config enables qutebrowser's native blocker with:

```nix
content.blocking.enabled = true;
content.blocking.method = "auto";
```

`auto` uses the Brave/ABP blocker when qutebrowser's optional adblock dependency is available and falls back to host blocking otherwise. After first launch, run this inside qutebrowser:

```text
:adblock-update
```

## Audio

PipeWire, PulseAudio compatibility, JACK compatibility and WirePlumber are enabled. Native Linux REAPER is installed. Windows DAWs under Wine need their own Wine audio bridge/driver; WineASIO is **not added in this revision** because it should be tested as a separate change rather than risking the now-known-good desktop build.

## Storage / rollback policy

`systemd-boot.configurationLimit = 3` exposes at most the current generation plus two previous boot entries. A weekly generation trimmer also keeps the system-profile history bounded and runs Nix garbage collection.

## Known-good fixes incorporated from the live T440 test

This revision contains the fixes discovered while testing on the laptop:

- real `st` Xresources patch hash (no `fakeHash` first-build failure);
- `intel-vaapi-driver` attribute name for NixOS 26.05;
- `xinit`, `xprop`, and `xrdb` current package names;
- obsolete `hardware.pulseaudio` option removed;
- RetroArch no longer uses the broken `.override { cores = ...; }` expression;
- Home Manager `.xinitrc` restores the wallpaper and starts Blueman applet;
- qutebrowser native ad blocking enabled;
- safe Git pull/test/apply workflow added.

## Before the first permanent switch of this revision

From the repository root:

```sh
nix flake check
sudo nixos-rebuild test --flake .#thinkpad
```

Test DWM, qutebrowser, `set-wallpaper`, audio, Wi-Fi, Bluetooth and the terminal. If good:

```sh
sudo nixos-rebuild switch --flake .#thinkpad
```

Then commit the exact tested `flake.lock`, `hardware-configuration.nix`, and config revision to GitHub.


## v7 pre-GitHub cleanup

This revision fixes several issues found during the live T440 test:

- `~/.local/bin` is explicitly on `PATH`, so `tmux-session`, `scratchpad`,
  `flstudio`, `audio-status`, `nix-sync`, and `nix-apply` can be launched reliably.
- Every helper script is explicitly executable.
- `Super+W` opens `set-wallpaper` inside `st`, because its Yazi image chooser is a
  terminal UI and cannot work correctly when spawned without a terminal.
- `blueman-applet` starts with X so `Super+Shift+M` can open Blueman Manager.
- `systemd-oomd` is enabled to reduce the chance of a full system freeze under
  memory pressure on the 4 GB machine.
- weekly SSD TRIM is enabled.
- `libva-utils` is installed, so `vainfo` is available for checking Intel
  hardware video decoding.
- duplicate `winetricks` installation was removed.
- systemd-boot's interactive editor is disabled; three boot configurations
  remain visible (current + two rollback choices).

### Before pushing publicly

Do not commit passwords, Wi-Fi PSKs, API keys, Wine prefixes, downloaded media,
or build logs. `hardware-configuration.nix` normally contains device/filesystem
identifiers but not passwords; decide whether you are comfortable publishing
those identifiers.


## v8 spatial workflow

v8 changes the default window-management philosophy:

- `st`, qutebrowser, and FL Studio/Wine are **tiled by default**, so they do not
  all open on top of the same coordinates.
- The official suckless `attachaside` patch for dwm 6.6 is vendored in the repo.
  New tiled applications enter the stack/available area rather than replacing
  the existing master window.
- mpv, RetroArch, the scratchpad, Bluetooth manager, and NetworkManager editor
  remain floating because that behavior fits their purpose.
- `Super+Space` selects normal tiling.
- `Super+Shift+Space` toggles only the focused window between tiled/floating.
- `Super+Ctrl+Space` selects monocle for a screen-filling work mode.
- `Super+Alt+Space` selects the fully floating layout for manual compositions.
- dmenu/dwm fallback colors use a paper-white + muted-blue palette inspired by
  the reference rice. No compositor, rounded corners, shadows, or borders were
  added.

This is intentionally a small patch set. More invasive old dwm patches such as
centeredmaster/vanitygaps were not stacked onto 6.6 because stability and easy
NixOS rebuilds matter more than patch count.
