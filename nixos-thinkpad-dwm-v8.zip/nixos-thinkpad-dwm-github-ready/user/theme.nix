{ pkgs, config, lib, ... }:
let
  home = config.home.homeDirectory;

  # Fallback palette used until you run set-wallpaper for the first time.
  defaultXresources = ''
    st.font: monospace:size=10
    st.borderpx: 0
    st.background: #151210
    st.foreground: #e8dcc8
    st.cursorColor: #c9a876
    st.color0:  #151210
    st.color1:  #a05c4c
    st.color2:  #8a9a5c
    st.color3:  #c9a876
    st.color4:  #7c8c9c
    st.color5:  #a87c9c
    st.color6:  #7c9c94
    st.color7:  #a89680
    st.color8:  #3a332c
    st.color9:  #c07c6c
    st.color10: #aabb7c
    st.color11: #e8c896
    st.color12: #9cacbc
    st.color13: #c89cbc
    st.color14: #9cbcb4
    st.color15: #e8dcc8
  '';

  setWallpaper = pkgs.writeShellScriptBin "set-wallpaper" ''
    set -euo pipefail
    IMG="''${1:-}"
    if [ -z "$IMG" ]; then
      IMG=$(${pkgs.yazi}/bin/yazi --chooser-file=/dev/stdout "$HOME/Pictures" 2>/dev/null || true)
    fi
    [ -n "$IMG" ] || { echo "no image chosen"; exit 1; }

    mkdir -p "$HOME/Pictures"
    cp -f "$IMG" "$HOME/Pictures/wallpaper.jpg"

    ${pkgs.feh}/bin/feh --bg-fill "$HOME/Pictures/wallpaper.jpg"
    ${pkgs.wallust}/bin/wallust run "$HOME/Pictures/wallpaper.jpg"

    xrdb -merge "$HOME/.Xresources"
    pkill -USR1 st 2>/dev/null || true
  '';
in
{
  home.packages = [ pkgs.wallust setWallpaper pkgs.xrdb ];

  # Seed a MUTABLE ~/.Xresources on first activation only. It has to be a real
  # file (not a nix-store symlink) because wallust overwrites it directly —
  # home.file would make it read-only and break set-wallpaper.
  home.activation.seedXresources = lib.hm.dag.entryAfter [ "writeBoundary" ] ''
    if [ ! -f "${home}/.Xresources" ]; then
      cat > "${home}/.Xresources" <<'EOF'
${defaultXresources}
EOF
    fi
  '';

  home.file.".config/wallust/wallust.toml".text = ''
    [templates]
    xresources = { template = "xresources", target = "${home}/.Xresources" }
  '';

  home.file.".config/wallust/templates/xresources".text = ''
    st.font: monospace:size=10
    st.borderpx: 0
    st.background: {{background}}
    st.foreground: {{foreground}}
    st.cursorColor: {{color4}}
    st.color0:  {{color0}}
    st.color1:  {{color1}}
    st.color2:  {{color2}}
    st.color3:  {{color3}}
    st.color4:  {{color4}}
    st.color5:  {{color5}}
    st.color6:  {{color6}}
    st.color7:  {{color7}}
    st.color8:  {{color8}}
    st.color9:  {{color9}}
    st.color10: {{color10}}
    st.color11: {{color11}}
    st.color12: {{color12}}
    st.color13: {{color13}}
    st.color14: {{color14}}
    st.color15: {{color15}}
  '';
}
