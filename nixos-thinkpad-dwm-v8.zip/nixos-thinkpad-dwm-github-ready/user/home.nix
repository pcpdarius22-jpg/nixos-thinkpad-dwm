{ pkgs, ... }: {
  home.username = "sloth";
  home.homeDirectory = "/home/sloth";

  imports = [ ./apps.nix ./theme.nix ];

  # Scripts installed below live here; this fixes tmux-session/scratchpad/etc.
  home.sessionPath = [ "$HOME/.local/bin" ];

  home.packages = with pkgs; [
    # Music production
    reaper       # native Linux DAW; Wine/FL Studio is configured separately
    yt-dlp
    pulsemixer
    sox          # command-line sampling/trimming/resampling

    # Terminal-centric daily drivers
    cmus         # music listening
    mpv          # movies / anime / YouTube playback (hardware-decoded via VAAPI)
    ytfzf        # fzf-driven YouTube search, plays through mpv
    zathura      # vim-keys PDF reader
    lynx         # ultra-light text browser (wtr-lab, etc.)

    # Torrents — fully terminal
    transmission_4
    tremc        # ncurses TUI for transmission-daemon

    # System info & files
    btop
    fastfetch
    feh          # sets the wallpaper (also a fallback light image viewer)
    yazi

    # Retro emulation — keep the standard package for release compatibility.
    retroarch

    brightnessctl
  ];

  # Auto-start X on the console you land on after autologin — no display manager.
  programs.bash.enable = true;
  programs.bash.profileExtra = ''
    if [ -z "$DISPLAY" ] && [ "$(tty)" = "/dev/tty1" ]; then
      exec startx
    fi
  '';

  programs.home-manager.enable = true;
  home.stateVersion = "24.11";
}
