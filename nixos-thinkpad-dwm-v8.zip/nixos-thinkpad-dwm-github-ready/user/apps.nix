{ pkgs, config, ... }:
let
  # st, patched so it re-reads colors/font from ~/.Xresources on `pkill -USR1 st`
  # (this is what lets wallust re-theme your terminal live when you change wallpaper).
  # Source: https://st.suckless.org/patches/xresources-with-reload-signal/
  myst = pkgs.st.overrideAttrs (old: {
    patches = (old.patches or [ ]) ++ [
      (pkgs.fetchpatch {
        url = "https://st.suckless.org/patches/xresources-with-reload-signal/st-xresources-signal-reloading-20220407-ef05519.diff";
        # Fixed-output hash verified during the T440 test build.
        hash = "sha256-0g6cJaMfn7zHfQ0xt6NKhWuDNY5UKZCjzcjJDJYsT5lrk=";
      })
    ];
  });

  myDmenu = pkgs.dmenu.override {
    conf = builtins.readFile ./suckless/dmenu-config.h;
  };
in
{
  home.packages = [
    pkgs.tmux pkgs.fzf pkgs.fd pkgs.ripgrep pkgs.zoxide pkgs.jq pkgs.lazygit
    pkgs.xdotool pkgs.xprop
    pkgs.wineWow64Packages.stable pkgs.winetricks
    myst myDmenu pkgs.qutebrowser ];
  home.sessionVariables.TERMINAL = "st";

  # xinitrc: restore wallpaper/theme, start the tiny Bluetooth helper, then dwm.
  home.file.".xinitrc".text = ''
    #!/bin/sh
    xrdb -merge "$HOME/.Xresources" 2>/dev/null
    if [ -f "$HOME/Pictures/wallpaper.jpg" ]; then
      ${pkgs.feh}/bin/feh --bg-fill "$HOME/Pictures/wallpaper.jpg" &
    fi
    ${pkgs.blueman}/bin/blueman-applet &
    exec dwm
  '';
  home.file.".xinitrc".executable = true;

  programs.zathura = {
    enable = true;
    options = {
      selection-clipboard = "clipboard";
      # neutral retro paper tone instead of stark white
      recolor = false;
      default-bg = "#e8dcc8";
      default-fg = "#151210";
    };
  };

  programs.qutebrowser = {
    enable = true;
    keyBindings.normal = {
      "d" = "tab-close";
      "u" = "undo";
    };
    settings = {
      colors.webpage.darkmode.enabled = true;
      tabs.show = "multiple";
      fonts.default_family = "monospace";
      content.javascript.enabled = true; # wtr-lab / tomato need JS
      content.blocking.enabled = true;
      content.blocking.method = "auto"; # Brave ABP blocker when available, hosts fallback otherwise
    };
  };

  # RetroArch: rgui text menu (near-zero GPU/RAM cost vs the default XMB menu)
  # — it also happens to match the retro-terminal look you're going for.
  home.file.".config/retroarch/retroarch.cfg".text = ''
    menu_driver = "rgui"
    video_driver = "gl"
    video_threaded = "true"
    video_vsync = "true"
    rgui_show_start_screen = "false"
    savestate_auto_save = "true"
    savestate_auto_load = "true"
  '';

  # Tiny workflow helpers. These are scripts, not daemons.
  home.file.".local/bin/tmux-session" = { source = ./scripts/tmux-session; executable = true; };
  home.file.".local/bin/wallpaper-menu" = { source = ./scripts/wallpaper-menu; executable = true; };
  home.file.".local/bin/app-menu" = { source = ./scripts/app-menu; executable = true; };
  home.file.".local/bin/scratchpad" = { source = ./scripts/scratchpad; executable = true; };
  home.file.".local/bin/flstudio" = { source = ./scripts/flstudio; executable = true; };
  home.file.".local/bin/audio-status" = { source = ./scripts/audio-status; executable = true; };
  home.file.".local/bin/nix-sync" = { source = ./scripts/nix-sync; executable = true; };
  home.file.".local/bin/nix-apply" = { source = ./scripts/nix-apply; executable = true; };
}
