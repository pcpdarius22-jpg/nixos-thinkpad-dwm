# ThinkPad T440 NixOS + dwm — v10

v10 is the **paper + blue** T440 setup built around the approved desktop mock-up: warm cream windows, charcoal text, muted blue selection, a very thin dwm bar, flat 1 px borders, no rounded corners, no compositor, and a terminal-first workflow.

## What the desktop is meant to look like

- warm paper background: `#eee8de`
- bright paper: `#f5f0e8`
- charcoal text: `#2b2d30`
- muted blue accent: `#527ca3`
- 5 workspaces on the left
- active window title centered in the top bar
- Wi-Fi, Bluetooth, volume, combined T440 battery state, and date/time on the right
- 1 px rectangular client borders
- no gaps patch, shadows, transparency, blur, rounded corners, tray, Polybar, Waybar, or compositor

The palette is deliberately **fixed**. Changing the wallpaper does not recolor the desktop.

## Stack

- NixOS 26.05 + Home Manager 26.05
- X11 + dwm
- st + dmenu
- Neovim + tmux
- yazi, btop, cmus, ytfzf
- qutebrowser + lynx
- zathura + mpv
- Transmission daemon on demand + tremc
- RetroArch
- native REAPER
- Wine + Winetricks + FL Studio helper
- PipeWire / WirePlumber / JACK compatibility
- NetworkManager + Blueman

## Repository layout

```text
nixos-thinkpad-dwm-v10/
├── flake.nix
├── flake.lock                       # keep/generate on the T440
├── README.md
├── system/
│   ├── configuration.nix
│   ├── audio.nix
│   └── hardware-configuration.nix  # KEEP the T440's real generated file
└── user/
    ├── apps.nix
    ├── home.nix
    ├── theme.nix
    ├── scripts/
    └── suckless/
        ├── dwm-config.h
        ├── dmenu-config.h
        └── patches/
```

`hardware-configuration.nix` and `flake.lock` are intentionally not invented in this archive. The hardware file must come from the actual laptop. Keep the existing lock file if the current installation already has one; otherwise generate it once with `nix flake lock` and commit it after testing.

## Safe upgrade from v8/v9

Do not overwrite the T440's hardware file.

From the new repository root:

```sh
# Copy these from the currently working checkout first:
cp /path/to/current/system/hardware-configuration.nix system/hardware-configuration.nix
cp /path/to/current/flake.lock flake.lock   # if it already exists

nix flake check
sudo nixos-rebuild test --flake .#thinkpad
```

`test` activates v10 without making it the next boot default. Verify X starts, DWM responds, networking/audio work, and the keybinds below launch correctly. Only then run:

```sh
sudo nixos-rebuild switch --flake .#thinkpad
```

For a completely fresh `sloth` user, set its password explicitly:

```sh
sudo passwd sloth
```

v10 does **not** ship a default password.

## Start-up model

The machine uses console autologin for `sloth`. Bash starts X from tty1, and NixOS generates the base `xinitrc` so the window manager and systemd user session are started correctly. v10 adds only three small startup actions:

1. load `.Xresources` for generic X applications;
2. restore `~/Pictures/wallpaper.jpg` if present;
3. launch the small `dwm-status` loop.

There is no display manager and no compositor.

If the laptop is not disk-encrypted and you do not want console autologin, remove:

```nix
services.getty.autologinUser = "sloth";
```

Then log in normally and `startx` will still start automatically on tty1 after login.

## Bar

The bar is the built-in dwm bar, not a separate panel.

```text
1  2  3  4  5                nvim  config.nix          WiFi  BT  Vol  Battery  Tue 12 Aug 22:31
```

The center-title patch keeps the active window title centered relative to the monitor. The right side comes from `user/scripts/dwm-status` and refreshes every 5 seconds.

On a T440 with two batteries, the script combines their values when they expose compatible capacity units; it avoids adding incompatible energy/charge units together.

## Main keybinds

`Super` is the main modifier.

| Key | Action |
|---|---|
| `Super + Enter` | st |
| `Super + T` | st + persistent tmux session |
| `Super + \`` | terminal scratchpad |
| `Super + D` | dmenu |
| `Super + B` | qutebrowser |
| `Super + E` | Neovim |
| `Super + Y` | yazi |
| `Super + X` | btop |
| `Super + M` | cmus |
| `Super + R` | tremc; starts Transmission daemon if needed |
| `Super + W` | wallpaper picker |
| `Super + G` | RetroArch |
| `Super + F` | FL Studio Wine helper |
| `Super + Shift + N` | NetworkManager connection editor |
| `Super + Shift + M` | Blueman Manager |
| `Super + Q` | close focused client |
| `Super + Shift + E` | quit dwm back to tty |

### Window management

| Key | Action |
|---|---|
| `Super + J / K` | next / previous client |
| `Super + H / L` | shrink / grow master |
| `Super + Shift + Enter` | promote focused client to master |
| `Super + Shift + Space` | toggle focused client floating |
| `Super + Space` | tiled layout |
| `Super + Ctrl + Space` | monocle layout |
| `Super + Alt + Space` | floating layout |
| `Super + 1..5` | view workspace |
| `Super + Shift + 1..5` | send client to workspace |
| `Super + Ctrl + 1..5` | toggle workspace in view |
| `Super + Ctrl + Shift + 1..5` | toggle client's workspace tag |
| `Super + 0` | view all workspaces |

The attachaside patch preserves the v8 workflow: new tiled clients go into the stack instead of constantly stealing the master position.

## Wallpaper

Put wallpapers in:

```text
~/Pictures/Wallpapers/
```

Press `Super + W`, choose one with `fzf`, and `set-wallpaper` copies it to:

```text
~/Pictures/wallpaper.jpg
```

That file is restored on the next X start. Wallpaper changes do not alter the v10 paper/blue application palette.

## Bluetooth and Wi-Fi

Bluetooth is powered at boot and Blueman's D-Bus/systemd integration is enabled, but **no permanent Blueman tray applet is launched**. The right-side bar icon reads BlueZ state directly. Use `Super + Shift + M` when you actually need the GUI manager.

NetworkManager handles Wi-Fi. Use `Super + Shift + N` for its connection editor. The bar reads connectivity directly with `nmcli`.

## Audio / music production

PipeWire, WirePlumber, PulseAudio compatibility and JACK compatibility are enabled. The default clock rate is 48 kHz with a 128-frame starting quantum. Native REAPER is included.

Media keys use `wpctl`; volume-up is capped at 100% to avoid accidental software amplification. `audio-status` prints the PipeWire graph and current default sink volume.

FL Studio is not bundled. The `flstudio` helper expects a Wine prefix at:

```text
~/.local/share/wine/flstudio
```

and searches it for `FL64.exe`.

## Torrents

`Super + R` runs the `torrents` helper. It starts `transmission-daemon` only when needed, waits briefly for it to appear, then launches `tremc`. There is no always-on torrent daemon in the desktop session.

## T440-specific system choices

- Intel/Haswell VA-API via `intel-vaapi-driver` / `i965`
- 32-bit graphics enabled for Wine
- zram plus a disk swap fallback
- `systemd-oomd`
- TLP + thermald
- charge thresholds for both `BAT0` and `BAT1`
- weekly SSD TRIM
- libinput for the TrackPoint/touchpad path
- systemd-boot capped to 3 entries
- weekly system-generation trimmer keeping the newest 3 generations

## GitHub update workflow

Once v10 is installed, these helpers are available in `~/.local/bin`.

### Pull and temporarily test

```sh
nix-sync
```

It refuses to pull over local changes, runs `git pull --ff-only`, checks the flake, and activates the new revision with `nixos-rebuild test`.

### Make the tested revision permanent

```sh
nix-apply
```

It checks the flake again and runs `nixos-rebuild switch`.

The default repository path is:

```text
~/nixos-thinkpad-dwm
```

Set `NIXOS_CONFIG_REPO` if yours lives elsewhere.

## What changed from v9

- restored the thin built-in dwm bar instead of `showbar = 0`
- reduced the desktop to 5 workspaces
- added the centered active-window title used by the approved mock-up
- replaced the brown/gold palette with fixed paper + muted blue
- removed Wallust-driven live recoloring
- replaced the old st runtime-Xresources patch with a much smaller compile-time color patch
- added Wi-Fi/Bluetooth/volume/dual-battery/date status text
- removed the always-running Blueman applet and enabled Blueman properly as a NixOS service
- fixed the invalid `wpctl get-default-sink` helper logic
- made Transmission start on demand for tremc
- enabled 32-bit graphics for Wine
- removed the insecure `initialPassword = "changeme"`
- enabled generated NixOS `startx` session handling instead of replacing it with a hand-written `.xinitrc`

## Validation performed before packaging

The archive was checked for:

- POSIX shell syntax (`dash -n`) and Bash syntax for every helper script
- C syntax of the custom dwm/dmenu config headers
- dry-run patch-context checks for the vendored dwm and st patches
- stale v9 references such as Wallust, disabled bar, old Bluetooth applet start-up, and the invalid PipeWire command
- archive integrity after packaging

The final authoritative check still has to happen on the T440 because this build environment does not contain the Nix evaluator. Always use `nix flake check` and `nixos-rebuild test` before `switch`.

## v10 safety guard

This archive includes an additional recovery guard around automatic X startup. If X/dwm ever fails repeatedly, create `~/.disable-x` from a TTY or rescue shell and reboot/login; tty1 will stay text-only instead of starting X. Remove the file when ready to try X again.

The user `~/.xinitrc` now delegates explicitly to NixOS' generated `/etc/X11/xinit/xinitrc`, so an older Home Manager xinitrc cannot silently take precedence. The systemd-boot entry editor is also enabled so rescue kernel parameters can be used if necessary.
