{ pkgs, ... }:
let
  dwmConfig = builtins.readFile ../user/suckless/dwm-config.h;
  myDwm = pkgs.dwm.override {
    conf = dwmConfig;
    patches = [
      ../user/suckless/patches/dwm-attachaside-6.6.diff
      ../user/suckless/patches/dwm-center-title-6.6.diff
    ];
  };
in
{
  # Keep the T440's real generated hardware file here. Do not replace it with
  # one from another machine.
  imports = [ ./hardware-configuration.nix ];

  boot.loader.systemd-boot = {
    enable = true;
    configurationLimit = 3;
    # Keep the boot entry editor available for rescue kernel parameters.
    editor = true;
  };
  boot.loader.efi.canTouchEfiVariables = true;
  boot.kernelParams = [
    "threadirqs"
    "snd_hda_intel.power_save=1"
  ];

  networking.hostName = "thinkpad";
  networking.networkmanager.enable = true;
  networking.firewall.enable = true;

  time.timeZone = "Europe/Bucharest";
  i18n.defaultLocale = "en_US.UTF-8";
  console.keyMap = "us";

  nix.settings = {
    experimental-features = [ "nix-command" "flakes" ];
    auto-optimise-store = true;
  };
  nixpkgs.config.allowUnfree = true;
  # T440 / Haswell HD 4400. i965 is the VA-API driver path used by this GPU.
  environment.variables.LIBVA_DRIVER_NAME = "i965";
  hardware.graphics = {
    enable = true;
    enable32Bit = true; # Wine/32-bit OpenGL support.
    extraPackages = with pkgs; [
      intel-vaapi-driver
      libvdpau-va-gl
    ];
  };

  # 4 GB machines benefit strongly from compressed swap and early OOM handling.
  zramSwap = {
    enable = true;
    memoryPercent = 50;
  };
  systemd.oomd.enable = true;
  swapDevices = [
    { device = "/var/lib/swapfile"; size = 4096; }
  ];

  services.tlp = {
    enable = true;
    settings = {
      CPU_SCALING_GOVERNOR_ON_AC = "performance";
      CPU_SCALING_GOVERNOR_ON_BAT = "powersave";
      CPU_ENERGY_PERF_POLICY_ON_AC = "performance";
      CPU_ENERGY_PERF_POLICY_ON_BAT = "power";
      START_CHARGE_THRESH_BAT0 = 40;
      STOP_CHARGE_THRESH_BAT0 = 80;
      START_CHARGE_THRESH_BAT1 = 40;
      STOP_CHARGE_THRESH_BAT1 = 80;
    };
  };
  services.thermald.enable = true;
  services.fstrim.enable = true;
  services.libinput.enable = true;
  services.blueman.enable = true;

  # Keep only a few system generations. The boot menu is also capped at three.
  systemd.services.nixos-generation-trimmer = {
    description = "Trim old NixOS system generations";
    serviceConfig.Type = "oneshot";
    script = ''
      ${pkgs.nix}/bin/nix-env -p /nix/var/nix/profiles/system --delete-generations +3 || true
      ${pkgs.nix}/bin/nix-collect-garbage
    '';
  };
  systemd.timers.nixos-generation-trimmer = {
    wantedBy = [ "timers.target" ];
    timerConfig = {
      OnCalendar = "weekly";
      Persistent = true;
    };
  };

  # X11 + dwm. No display manager and no compositor.
  services.xserver = {
    enable = true;
    xkb.layout = "us";
    windowManager.dwm = {
      enable = true;
      package = myDwm;
    };
    displayManager.startx = {
      enable = true;
      generateScript = true;
      extraCommands = ''
        ${pkgs.xorg.xrdb}/bin/xrdb -merge "$HOME/.Xresources" 2>/dev/null || true
        if [ -f "$HOME/Pictures/wallpaper.jpg" ]; then
          ${pkgs.feh}/bin/feh --bg-fill "$HOME/Pictures/wallpaper.jpg" &
        fi
        "$HOME/.local/bin/dwm-status" &
      '';
    };
  };

  # Console autologin -> bash profile -> startx. If your disk is not encrypted,
  # remove this and log in normally if you prefer a login password at boot.
  services.getty.autologinUser = "sloth";

  security.polkit.enable = true;
  security.rtkit.enable = true;

  # Icon glyphs used by the thin dwm status bar.
  fonts.packages = [ pkgs.nerd-fonts.symbols-only ];

  environment.systemPackages = with pkgs; [
    git
    vim
    curl
    wget
    unzip
    libva-utils
    networkmanagerapplet
  ];

  users.users.sloth = {
    isNormalUser = true;
    extraGroups = [ "wheel" "networkmanager" "audio" "video" ];
    # Existing installs keep the password already stored in /etc/shadow.
    # For a fresh install, set it explicitly with: passwd sloth
  };

  # Keep this at the version used when the machine was first installed.
  system.stateVersion = "24.11";
}
