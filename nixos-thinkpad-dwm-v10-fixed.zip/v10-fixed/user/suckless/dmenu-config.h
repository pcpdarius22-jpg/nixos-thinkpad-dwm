/* dmenu config.h — v10 warm-paper / muted-blue palette */
static int topbar = 1;
static const char *fonts[] = { "monospace:size=10" };
static const char *prompt = NULL;
static const char *colors[SchemeLast][2] = {
    /*                fg          bg */
    [SchemeNorm] = { "#2b2d30", "#eee8de" },
    [SchemeSel]  = { "#f5f0e8", "#527ca3" },
    [SchemeOut]  = { "#f5f0e8", "#a06a58" },
};
static unsigned int lines = 0;
static const char worddelimiters[] = " ";
