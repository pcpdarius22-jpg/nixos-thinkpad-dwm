/* dwm config.h — v10 paper/blue rice for ThinkPad T440
 * The bar/theme is deliberately compiled into dwm: small, predictable, fast.
 */

#include <X11/XF86keysym.h>

/* appearance */
static const unsigned int borderpx  = 1;
static const unsigned int snap      = 32;
static const int showbar            = 1;
static const int topbar             = 1;
static const char *fonts[]          = {
    "monospace:size=9",
    "Symbols Nerd Font Mono:size=9"
};
static const char dmenufont[]       = "monospace:size=10";

/* fixed v10 palette: warm paper + charcoal + muted blue */
static const char col_bg[]          = "#eee8de";
static const char col_bg_bright[]   = "#f5f0e8";
static const char col_fg[]          = "#2b2d30";
static const char col_muted[]       = "#aaa59d";
static const char col_accent[]      = "#527ca3";

static const char *colors[][3] = {
    /*               fg          bg      border */
    [SchemeNorm] = { col_fg,     col_bg, col_muted  },
    [SchemeSel]  = { col_accent, col_bg, col_accent },
};

/* five visible workspaces, matching the approved mock-up */
static const char *tags[] = { "1", "2", "3", "4", "5" };

static const Rule rules[] = {
    /* class                   instance      title   tags mask  float  monitor */
    { "mpv",                  NULL,         NULL,   0,         1,     -1 },
    { "qutebrowser",          NULL,         NULL,   0,         0,     -1 },
    { "retroarch",            NULL,         NULL,   0,         1,     -1 },
    { "FL64.exe",             NULL,         NULL,   0,         0,     -1 },
    { "st",                   NULL,         NULL,   0,         0,     -1 },
    { NULL,                    "scratchpad", NULL,   0,         1,     -1 },
    { "Blueman-manager",      NULL,         NULL,   0,         1,     -1 },
    { "Nm-connection-editor", NULL,         NULL,   0,         1,     -1 },
};

/* layouts */
static const float mfact     = 0.55;
static const int nmaster     = 1;
static const int resizehints = 0;
static const int lockfullscreen = 1;

/* Empty symbols keep the top bar visually quiet. */
static const Layout layouts[] = {
    { "", tile },
    { "", NULL },
    { "", monocle },
};

/* keys */
#define MODKEY Mod4Mask
#define TAGKEYS(KEY,TAG) \
    { MODKEY,                       KEY, view,       {.ui = 1 << TAG} }, \
    { MODKEY|ControlMask,           KEY, toggleview, {.ui = 1 << TAG} }, \
    { MODKEY|ShiftMask,             KEY, tag,        {.ui = 1 << TAG} }, \
    { MODKEY|ControlMask|ShiftMask, KEY, toggletag,  {.ui = 1 << TAG} },

#define SHCMD(cmd) { .v = (const char*[]){ "/bin/sh", "-c", cmd, NULL } }

static char dmenumon[2] = "0";
static const char *dmenucmd[] = {
    "dmenu_run", "-m", dmenumon, "-fn", dmenufont,
    "-nb", col_bg, "-nf", col_fg, "-sb", col_accent, "-sf", col_bg_bright,
    NULL
};
static const char *termcmd[] = { "st", "-g", "90x30", NULL };
static const char *tmuxcmd[] = { "st", "-g", "100x32", "-e", "tmux-session", NULL };

static const Key keys[] = {
    /* launch / session */
    { MODKEY,                       XK_Return, spawn,          {.v = termcmd } },
    { MODKEY,                       XK_t,      spawn,          {.v = tmuxcmd } },
    { MODKEY,                       XK_grave,  spawn,          SHCMD("scratchpad") },
    { MODKEY,                       XK_d,      spawn,          {.v = dmenucmd } },
    { MODKEY,                       XK_q,      killclient,     {0} },
    { MODKEY|ShiftMask,             XK_e,      quit,           {0} },

    /* terminal-first apps */
    { MODKEY,                       XK_b,      spawn,          SHCMD("qutebrowser") },
    { MODKEY,                       XK_e,      spawn,          SHCMD("st -g 100x34 -e nvim") },
    { MODKEY,                       XK_f,      spawn,          SHCMD("flstudio") },
    { MODKEY|ShiftMask,             XK_b,      spawn,          SHCMD("st -g 100x32 -e lynx https://wtr-lab.com") },
    { MODKEY,                       XK_y,      spawn,          SHCMD("st -g 100x32 -e yazi") },
    { MODKEY,                       XK_g,      spawn,          SHCMD("retroarch") },
    { MODKEY,                       XK_x,      spawn,          SHCMD("st -g 90x30 -e btop") },
    { MODKEY,                       XK_m,      spawn,          SHCMD("st -g 90x24 -e cmus") },
    { MODKEY,                       XK_r,      spawn,          SHCMD("st -g 100x32 -e torrents") },
    { MODKEY,                       XK_w,      spawn,          SHCMD("st -g 100x32 -e wallpaper-menu") },
    { MODKEY|ShiftMask,             XK_n,      spawn,          SHCMD("nm-connection-editor") },
    { MODKEY|ShiftMask,             XK_m,      spawn,          SHCMD("blueman-manager") },

    /* focus / layout */
    { MODKEY,                       XK_j,      focusstack,     {.i = +1 } },
    { MODKEY,                       XK_k,      focusstack,     {.i = -1 } },
    { MODKEY,                       XK_h,      setmfact,       {.f = -0.05} },
    { MODKEY,                       XK_l,      setmfact,       {.f = +0.05} },
    { MODKEY|ShiftMask,             XK_Return, zoom,           {0} },
    { MODKEY|ShiftMask,             XK_space,  togglefloating, {0} },
    { MODKEY,                       XK_Tab,    focusstack,     {.i = +1 } },
    { MODKEY,                       XK_space,  setlayout,      {.v = &layouts[0] } },
    { MODKEY|ControlMask,           XK_space,  setlayout,      {.v = &layouts[2] } },
    { MODKEY|Mod1Mask,              XK_space,  setlayout,      {.v = &layouts[1] } },
    { MODKEY,                       XK_0,      view,           {.ui = ~0 } },
    { MODKEY|ShiftMask,             XK_0,      tag,            {.ui = ~0 } },
    { MODKEY,                       XK_comma,  focusmon,       {.i = -1 } },
    { MODKEY,                       XK_period, focusmon,       {.i = +1 } },

    TAGKEYS(XK_1, 0)
    TAGKEYS(XK_2, 1)
    TAGKEYS(XK_3, 2)
    TAGKEYS(XK_4, 3)
    TAGKEYS(XK_5, 4)

    /* media / brightness */
    { 0, XF86XK_AudioRaiseVolume,  spawn, SHCMD("wpctl set-volume -l 1.0 @DEFAULT_AUDIO_SINK@ 5%+") },
    { 0, XF86XK_AudioLowerVolume,  spawn, SHCMD("wpctl set-volume @DEFAULT_AUDIO_SINK@ 5%-") },
    { 0, XF86XK_AudioMute,         spawn, SHCMD("wpctl set-mute @DEFAULT_AUDIO_SINK@ toggle") },
    { 0, XF86XK_MonBrightnessUp,   spawn, SHCMD("brightnessctl set +10%") },
    { 0, XF86XK_MonBrightnessDown, spawn, SHCMD("brightnessctl set 10%-") },
};

static const Button buttons[] = {
    { ClkLtSymbol, 0,      Button1, setlayout,      {0} },
    { ClkWinTitle, 0,      Button2, zoom,           {0} },
    { ClkClientWin, MODKEY, Button1, movemouse,      {0} },
    { ClkClientWin, MODKEY, Button2, togglefloating, {0} },
    { ClkClientWin, MODKEY, Button3, resizemouse,    {0} },
    { ClkTagBar,    0,      Button1, view,           {0} },
    { ClkTagBar,    0,      Button3, toggleview,     {0} },
    { ClkTagBar,    MODKEY, Button1, tag,            {0} },
    { ClkTagBar,    MODKEY, Button3, toggletag,      {0} },
};
