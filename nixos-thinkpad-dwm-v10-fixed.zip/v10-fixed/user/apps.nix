{ pkgs, ... }:
let
  # Patch only st's compile-time palette/font. v10 intentionally avoids the
  # old runtime Xresources patch: the theme is fixed and this is much less
  # fragile across rebuilds.
  myst = pkgs.st.override {
    patches = [ ./suckless/patches/st-v10-colors-0.9.3.diff ];
  };

  myDmenu = pkgs.dmenu.override {
    conf = builtins.readFile ./suckless/dmenu-config.h;
  };
in
{
  home.packages = with pkgs; [
    fzf
    fd
    ripgrep
    zoxide
    jq
    lazygit
    xdotool
    xorg.xprop
    wineWow64Packages.stable
    winetricks
    myst
    myDmenu
  ];

  programs.zathura = {
    enable = true;
    options = {
      selection-clipboard = "clipboard";
      recolor = false;
      default-bg = "#eee8de";
      default-fg = "#2b2d30";
      statusbar-bg = "#eee8de";
      statusbar-fg = "#2b2d30";
      inputbar-bg = "#eee8de";
      inputbar-fg = "#2b2d30";
      highlight-color = "#527ca3";
      highlight-active-color = "#527ca3";
    };
  };

  programs.qutebrowser = {
    enable = true;
    keyBindings.normal = {
      "d" = "tab-close";
      "u" = "undo";
    };
    settings = {
      tabs.show = "multiple";
      tabs.position = "top";
      statusbar.show = "in-mode";
      fonts.default_family = "monospace";
      fonts.default_size = "10pt";
      fonts.statusbar = "9pt monospace";
      fonts.tabs.selected = "9pt monospace";
      fonts.tabs.unselected = "9pt monospace";

      content.javascript.enabled = true;
      content.blocking.enabled = true;
      content.blocking.method = "auto";

      colors.webpage.darkmode.enabled = false;
      colors.webpage.preferred_color_scheme = "light";
      colors.webpage.bg = "#eee8de";

      colors.tabs.bar.bg = "#eee8de";
      colors.tabs.even.bg = "#eee8de";
      colors.tabs.odd.bg = "#eee8de";
      colors.tabs.even.fg = "#4b4b4b";
      colors.tabs.odd.fg = "#4b4b4b";
      colors.tabs.selected.even.bg = "#527ca3";
      colors.tabs.selected.odd.bg = "#527ca3";
      colors.tabs.selected.even.fg = "#f5f0e8";
      colors.tabs.selected.odd.fg = "#f5f0e8";
      colors.tabs.indicator.start = "#527ca3";
      colors.tabs.indicator.stop = "#527ca3";

      colors.statusbar.normal.bg = "#eee8de";
      colors.statusbar.normal.fg = "#2b2d30";
      colors.statusbar.command.bg = "#eee8de";
      colors.statusbar.command.fg = "#2b2d30";
      colors.statusbar.insert.bg = "#527ca3";
      colors.statusbar.insert.fg = "#f5f0e8";
      colors.statusbar.url.fg = "#527ca3";
      colors.statusbar.url.success.http.fg = "#527ca3";
      colors.statusbar.url.success.https.fg = "#527ca3";
      colors.statusbar.progress.bg = "#527ca3";
    };
  };

  home.file.".config/retroarch/retroarch.cfg".text = ''
    menu_driver = "rgui"
    video_driver = "gl"
    video_threaded = "true"
    video_vsync = "true"
    rgui_show_start_screen = "false"
    savestate_auto_save = "true"
    savestate_auto_load = "true"
  '';

  home.file.".local/bin/tmux-session" = { source = ./scripts/tmux-session; executable = true; };
  home.file.".local/bin/wallpaper-menu" = { source = ./scripts/wallpaper-menu; executable = true; };
  home.file.".local/bin/app-menu" = { source = ./scripts/app-menu; executable = true; };
  home.file.".local/bin/scratchpad" = { source = ./scripts/scratchpad; executable = true; };
  home.file.".local/bin/flstudio" = { source = ./scripts/flstudio; executable = true; };
  home.file.".local/bin/audio-status" = { source = ./scripts/audio-status; executable = true; };
  home.file.".local/bin/dwm-status" = { source = ./scripts/dwm-status; executable = true; };
  home.file.".local/bin/torrents" = { source = ./scripts/torrents; executable = true; };
  home.file.".local/bin/nix-sync" = { source = ./scripts/nix-sync; executable = true; };
  home.file.".local/bin/nix-apply" = { source = ./scripts/nix-apply; executable = true; };
}
