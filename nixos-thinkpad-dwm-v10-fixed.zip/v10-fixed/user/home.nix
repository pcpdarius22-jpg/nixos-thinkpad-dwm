{ pkgs, ... }: {
  home.username = "sloth";
  home.homeDirectory = "/home/sloth";

  imports = [ ./apps.nix ./theme.nix ];

  home.sessionPath = [ "$HOME/.local/bin" ];
  home.sessionVariables = {
    TERMINAL = "st";
    EDITOR = "nvim";
    VISUAL = "nvim";
    BROWSER = "qutebrowser";
  };

  home.packages = with pkgs; [
    # Music / production
    reaper
    yt-dlp
    pulsemixer
    sox

    # Terminal-first daily tools
    cmus
    ytfzf
    lynx
    yazi
    btop
    fastfetch
    feh

    # Torrents
    transmission_4
    tremc

    # Retro / hardware controls
    retroarch
    brightnessctl

    # Commands used by the bar and helpers
    wireplumber
    procps
    xorg.xsetroot
  ];

  programs.bash = {
    enable = true;
    profileExtra = ''
      # Safety guard: create ~/.disable-x from any TTY/rescue shell to boot
      # to a console without automatically starting X.
      if [ -z "$DISPLAY" ] && [ "$(tty)" = "/dev/tty1" ] && [ ! -e "$HOME/.disable-x" ]; then
        startx || printf '\nX exited. Staying on tty1. Create ~/.disable-x to skip X next login.\n'
      fi
    '';
    bashrcExtra = ''
      # Small blue prompt; deliberately no framework or prompt daemon.
      PS1='\[\e[38;2;82;124;163m\]\u@\h\[\e[0m\] \w \\$ '
    '';
  };

  # Keep ~/.xinitrc deterministic. startx normally prefers a user xinitrc;
  # delegate it explicitly to NixOS' generated session script so an older
  # Home Manager xinitrc cannot silently override v10 session handling.
  home.file.".xinitrc" = {
    executable = true;
    text = ''
      #!/bin/sh
      exec /etc/X11/xinit/xinitrc
    '';
  };

  programs.tmux = {
    enable = true;
    baseIndex = 1;
    escapeTime = 0;
    mouse = true;
    terminal = "screen-256color";
    extraConfig = ''
      set -as terminal-features ',*:RGB'
      set -g status-position bottom
      set -g status-style 'bg=#eee8de,fg=#2b2d30'
      set -g status-left '#S '
      set -g status-right '%H:%M '
      set -g window-status-format ' #I:#W '
      set -g window-status-current-format ' #I:#W '
      set -g window-status-current-style 'fg=#527ca3,bold,bg=#eee8de'
      set -g pane-border-style 'fg=#aaa59d'
      set -g pane-active-border-style 'fg=#527ca3'
    '';
  };

  programs.neovim = {
    enable = true;
    defaultEditor = true;
    viAlias = true;
    vimAlias = true;
    extraLuaConfig = ''
      vim.opt.number = true
      vim.opt.relativenumber = false
      vim.opt.cursorline = false
      vim.opt.termguicolors = true
      vim.opt.signcolumn = "no"
      vim.opt.laststatus = 2
      vim.opt.showmode = false
      vim.opt.title = true
      vim.opt.titlestring = "nvim  %t"
      vim.opt.statusline = " %f %= %l:%c "
      vim.opt.tabstop = 2
      vim.opt.shiftwidth = 2
      vim.opt.expandtab = true
      vim.opt.smartindent = true
      vim.opt.ignorecase = true
      vim.opt.smartcase = true
      vim.opt.updatetime = 250

      local set = vim.api.nvim_set_hl
      set(0, "Normal",       { fg = "#2b2d30", bg = "NONE" })
      set(0, "NormalFloat",  { fg = "#2b2d30", bg = "#eee8de" })
      set(0, "LineNr",       { fg = "#9a9690", bg = "NONE" })
      set(0, "CursorLineNr", { fg = "#527ca3", bg = "NONE", bold = true })
      set(0, "StatusLine",   { fg = "#eee8de", bg = "#527ca3" })
      set(0, "StatusLineNC", { fg = "#6d6a66", bg = "#ded8ce" })
      set(0, "Visual",       { fg = "#eee8de", bg = "#527ca3" })
      set(0, "Search",       { fg = "#2b2d30", bg = "#c8b078" })
      set(0, "Comment",      { fg = "#77736e", bg = "NONE", italic = true })
      set(0, "String",       { fg = "#6f8060", bg = "NONE" })
      set(0, "Number",       { fg = "#a06a58", bg = "NONE" })
      set(0, "Boolean",      { fg = "#527ca3", bg = "NONE" })
      set(0, "Identifier",   { fg = "#3f6f82", bg = "NONE" })
      set(0, "Statement",    { fg = "#7a6583", bg = "NONE", bold = true })
      set(0, "Type",         { fg = "#587b73", bg = "NONE" })
      set(0, "PreProc",      { fg = "#9b7448", bg = "NONE" })
    '';
  };

  programs.mpv = {
    enable = true;
    config = {
      hwdec = "auto-safe";
      vo = "gpu";
      keep-open = "yes";
      save-position-on-quit = "yes";
    };
  };

  # Make btop use the terminal's paper/blue 16-color palette instead of
  # painting a separate dark theme over st.
  home.file.".config/btop/btop.conf".text = ''
    color_theme = "TTY"
    theme_background = false
    truecolor = false
    force_tty = true
    rounded_corners = false
    vim_keys = true
    shown_boxes = "cpu mem proc"
    update_ms = 2000
    show_battery = false
  '';

  # cmus follows st's palette: paper background and blue selections/title.
  home.file.".config/cmus/rc".text = ''
    set color_win_bg=default
    set color_win_fg=default
    set color_win_cur=blue
    set color_win_sel_bg=blue
    set color_win_sel_fg=white
    set color_win_cur_sel_bg=blue
    set color_win_cur_sel_fg=white
    set color_win_inactive_sel_bg=gray
    set color_win_inactive_sel_fg=black
    set color_titleline_bg=default
    set color_titleline_fg=blue
    set color_statusline_bg=default
    set color_statusline_fg=blue
    set color_separator=blue
    set set_term_title=true
    set format_title=cmus  %a - %t
  '';

  programs.home-manager.enable = true;
  home.stateVersion = "24.11";
}
