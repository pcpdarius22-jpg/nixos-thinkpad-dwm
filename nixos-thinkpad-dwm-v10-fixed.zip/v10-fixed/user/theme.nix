{ pkgs, ... }:
let
  setWallpaper = pkgs.writeShellScriptBin "set-wallpaper" ''
    set -eu
    if [ "$#" -ne 1 ]; then
      echo "usage: set-wallpaper /path/to/image"
      exit 2
    fi
    IMG="$1"
    [ -f "$IMG" ] || { echo "not a file: $IMG"; exit 1; }

    mkdir -p "$HOME/Pictures"
    cp -f -- "$IMG" "$HOME/Pictures/wallpaper.jpg"
    ${pkgs.feh}/bin/feh --bg-fill "$HOME/Pictures/wallpaper.jpg"
  '';
in
{
  home.packages = [ setWallpaper ];

  # Generic Xresources fallback for small X11 programs. st/dmenu/dwm have the
  # same palette compiled/configured directly, so this file is not a runtime
  # dependency of the desktop theme.
  home.file.".Xresources".text = ''
    *background: #eee8de
    *foreground: #2b2d30
    *cursorColor: #527ca3
    *color0:  #25272a
    *color1:  #a65f58
    *color2:  #6f8060
    *color3:  #a4824f
    *color4:  #527ca3
    *color5:  #806c8b
    *color6:  #587e78
    *color7:  #d7d1c8
    *color8:  #6d6a66
    *color9:  #b86c63
    *color10: #7f916f
    *color11: #b8965c
    *color12: #6d92b4
    *color13: #967da0
    *color14: #6c948d
    *color15: #f5f0e8
  '';
}
