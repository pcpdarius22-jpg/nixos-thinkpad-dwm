# nixos-thinkpad

Suckless-style NixOS config for a ThinkPad T440 (i5-4300U, 4GB RAM, 500GB SSD).
X11 + dwm + st + dmenu (no bar, no slstatus). No display manager, no compositor, no GTK/Qt
desktop shell. Terminal-first everywhere it's realistic to be.

## What's here

```
flake.nix
system/
  configuration.nix   # boot, X11+dwm, power, network, users
  audio.nix            # pipewire + bluetooth
user/
  home.nix             # package list, auto-startx
  apps.nix             # st/dmenu builds, qutebrowser, zathura, retroarch
  theme.nix            # wallust + Xresources live-theming + set-wallpaper
  suckless/
    dwm-config.h        # dwm source config — edit + rebuild to change keybinds/colors
    dmenu-config.h
    slstatus-config.h
```

`system/hardware-configuration.nix` is **not** in this repo — it's auto-generated
per-machine during install (see below) and shouldn't be hand-edited or reused
on different hardware.

## Why dwm over the previous sway/waybar setup

You said the bloat you felt was GTK-based desktop shell pieces (waybar, fuzzel,
nm-applet, blueman-applet) sitting in RAM even when idle. dwm/st/dmenu
are plain Xlib C binaries with zero GTK/Qt dependency — rough idle comparison:

| stack | idle RAM (desktop shell only) |
|---|---|
| sway + waybar + fuzzel (GTK) | ~500–700MB |
| dwm + st + dmenu + slstatus | ~80–150MB |

These are ballpark estimates, not benchmarked on your exact hardware — but the
order of magnitude difference is real and comes from cutting the GTK stack, not
from anything sway-specific.

**Tradeoff you're accepting:** dwm's keybinds, colors, and layout are compiled
into a C file (`dwm-config.h`). There's no live-reload — changing a keybind
means editing the file and running `sudo nixos-rebuild switch`. That's normal
for suckless tools, not a bug. It compiles in a few seconds since it's tiny.

## How theming works

Vanilla dwm and dmenu use a **static** retro brown/beige palette baked into
their config.h files — already matching the look in your reference image, no
wallpaper-linking needed for these (they're a handful of border/bar pixels, low
visual impact).

**st (your terminal) re-themes live from your wallpaper.** It's patched with
[st's official xresources-with-reload-signal patch](https://st.suckless.org/patches/xresources-with-reload-signal/),
which makes it read colors from `~/.Xresources` and reload on `SIGUSR1` — no
rebuild, no restart.

Run:
```
set-wallpaper ~/Pictures/some-image.jpg
```
or just `set-wallpaper` with no argument to pick one via a yazi file-chooser
popup (bound to `MODKEY+w`). This will:
1. Copy the image to `~/Pictures/wallpaper.jpg` and set it as the root background (`feh`)
2. Run `wallust` to extract a palette and write it into `~/.Xresources`
3. Reload the X resource database and signal all open `st` windows to re-theme instantly

If you later want dwm's bar/borders to shift with the wallpaper too, that's
possible but needs the same patch treatment applied to dwm itself — ask and
I'll do it as a follow-up.

## Retro emulation — realistic expectations on this hardware

This is a dual-core Haswell ULV chip with a weak integrated GPU (HD 4400), no
dedicated graphics. Realistic per-system expectations:

| system | verdict |
|---|---|
| NES / SNES / GB / GBA / NDS / Genesis | full speed, no concerns |
| N64 | mostly full speed; a few demanding titles will chug |
| PS1 | full speed (DuckStation) |
| PSP | full speed (PPSSPP) |
| Dreamcast | generally fine (Flycast) |
| **PS2** | marginal — light/2D-ish titles may work, most 3D-heavy games (GTA, FF X) won't hit full speed |
| **3DS** | not included in this config. Citra was shut down after Nintendo's 2024 lawsuit; the current community successor is **Azahar**, which is likely too new for the nixpkgs channel this flake pins. If you want to try it, install via Flatpak (`services.flatpak.enable = true;`) rather than fighting the flake for it — and temper expectations, 3DS emulation is CPU/3D-heavy and this iGPU will struggle on most titles. |

RetroArch is configured to boot into the **rgui** menu (plain text, near-zero
GPU cost) instead of the default XMB menu — both lighter and more in-theme.

## VPN / torrenting

Deliberately **not** hardcoding a VPN provider in this config — free-tier VPN
P2P policies change often and are inconsistently enforced (ProtonVPN's free
tier blocks P2P entirely; other providers' free-tier P2P support has flipped
back and forth). Instead, `networkmanagerapplet` is installed system-wide so
you can import whichever provider's OpenVPN/WireGuard config file you land on
via `nm-connection-editor` (`MODKEY+Shift+N`), same picker either way.

Torrents run through **transmission-daemon** (background service) + **tremc**
(ncurses TUI, `MODKEY+t` or run `tremc` in any terminal) — no browser, no GUI
client sitting in RAM.

## Fresh install, step by step

1. **Download the NixOS minimal ISO** and write it to a USB stick (Etcher,
   `dd`, or Rufus). Graphical ISO also works but minimal boots faster and you
   won't use the GUI installer anyway.

2. **Boot from USB** on the T440 (F12 for boot menu). Confirm you're booting
   in UEFI mode, not legacy/CSM — check the BIOS if the boot menu doesn't show
   the USB as a UEFI entry.

3. **Connect to wifi** in the live environment:
   ```
   nmtui
   ```
   Pick your network, enter the password.

4. **Enable flakes for this session** (the live ISO doesn't have them on by default):
   ```
   export NIX_CONFIG="experimental-features = nix-command flakes"
   ```

5. **Partition the disk.** Replace `/dev/sda` with your actual disk (`lsblk` to check):
   ```
   sudo cfdisk /dev/sda
   ```
   Create:
   - a 512MB EFI System partition (type "EFI System")
   - the rest as a Linux partition (type "Linux filesystem")

   No separate swap partition — we use a swapfile + zram, both handled by the
   config later. Then format:
   ```
   sudo mkfs.fat -F32 -n boot /dev/sda1
   sudo mkfs.ext4 -L nixos /dev/sda2
   ```

6. **Mount everything:**
   ```
   sudo mount /dev/disk/by-label/nixos /mnt
   sudo mkdir -p /mnt/boot
   sudo mount /dev/disk/by-label/boot /mnt/boot
   ```

7. **Generate the hardware config:**
   ```
   sudo nixos-generate-config --root /mnt
   ```
   This creates `/mnt/etc/nixos/hardware-configuration.nix` — the one file this
   repo intentionally doesn't ship, because it's specific to your exact disk/EFI setup.

8. **Get this repo onto the machine.** Easiest if you've already pushed it to
   GitHub:
   ```
   nix shell nixpkgs#git -c git clone https://github.com/<you>/nixos-thinkpad /mnt/etc/nixos-repo
   sudo cp /mnt/etc/nixos/hardware-configuration.nix /mnt/etc/nixos-repo/system/hardware-configuration.nix
   sudo rm -rf /mnt/etc/nixos
   sudo mv /mnt/etc/nixos-repo /mnt/etc/nixos
   ```

9. **Fix the st patch hash** (one-time, see note below), then install:
   ```
   sudo nixos-install --root /mnt --flake /mnt/etc/nixos#thinkpad --no-root-passwd
   ```

10. **Reboot, remove the USB.** You'll land straight into a `sloth` login
    (autologin is on) which auto-runs `startx` into dwm.

11. **Set a real password:**
    ```
    passwd
    ```
    (the config ships with a placeholder — `changeme` — specifically so you
    have to do this)

## The "hash trick" (you'll hit this once, on first build)

`apps.nix` fetches the st xresources patch with a placeholder hash
(`pkgs.lib.fakeHash`) because this sandbox has no network access to compute
the real one. **This is expected and normal in Nix** — not a bug you need to
fix by hand-guessing:

1. Run the rebuild. It will fail with an error like:
   ```
   error: hash mismatch in fixed-output derivation ...
     specified: sha256-AAAA...
     got:       sha256-xK3jf9...
   ```
2. Copy the `got:` hash.
3. Open `user/apps.nix`, replace `pkgs.lib.fakeHash` with that hash (as a quoted string).
4. Rebuild again — it'll succeed this time.

## Day-to-day usage

**Rebuild after any edit:**
```
sudo nixos-rebuild switch --flake /etc/nixos#thinkpad
```

**Roll back if something breaks:** reboot and pick the previous generation
from the systemd-boot menu, or:
```
sudo nixos-rebuild switch --rollback
```

**Keybinds** (MODKEY = Super/Windows key):

| keys | action |
|---|---|
| `MOD+Return` | open st |
| `MOD+d` | dmenu (app launcher) |
| `MOD+q` | close focused window |
| `MOD+Shift+e` | quit dwm (logs you out) |
| `MOD+Shift+r` | restart dwm (after a rebuild, no logout needed) |
| `MOD+b` | qutebrowser |
| `MOD+Shift+b` | wtr-lab in lynx |
| `MOD+y` | yazi (file manager) |
| `MOD+g` | RetroArch |
| `MOD+x` | btop |
| `MOD+m` | cmus |
| `MOD+t` | tremc (torrents) |
| `MOD+w` | pick a new wallpaper + re-theme |
| `MOD+Shift+n` | wifi (nm-connection-editor) |
| `MOD+Shift+m` | bluetooth (blueman-manager) |
| `MOD+j` / `MOD+k` | cycle focus |
| `MOD+h` / `MOD+l` | shrink/grow master area |
| `MOD+1..9` | switch tag (workspace) |
| `MOD+Shift+1..9` | move window to tag |
| `MOD+space` | cycle layout (tile / floating / monocle) |

Full keybind and color source: `user/suckless/dwm-config.h`.

## Known limitations, on purpose

- **PS2/3DS emulation isn't going to be great** on this hardware, see table above.
- **dwm/dmenu chrome doesn't re-theme with wallpaper** (only st does) — a
  deliberate scope cut to avoid patching two more C programs; can be added later.
- **No VPN baked in** — bring your own config file via nm-connection-editor.


## Brutalist floating-window mode

The desktop is intentionally a canvas: no dwm bar, no window borders, no rounded
corners, and no decorative widgets. `st` opens as a centered floating 90x30
rectangle. Terminal applications launched through `st -e ...` inherit the same
floating rule. `Super+Space` can still switch layouts when tiled windows are
actually useful.

`slstatus` is not installed or started. System information is opened on demand
with tools such as `btop`, `fastfetch`, and shell commands.

`xrdb` is included explicitly because both `.xinitrc` and `set-wallpaper` use it.


## Workflow v3

The machine is intentionally built around a small set of composable tools:

- `dwm`: window management only; no bar and zero borders.
- `st`: moderate floating terminal rectangle by default.
- `tmux`: persistent terminal workspaces.
- `fzf`, `fd`, `ripgrep`, `zoxide`, `jq`: fast retrieval/navigation/data tools.
- `lazygit`: Git UI without a desktop client.
- `yazi`, `qutebrowser`, `zathura`, `mpv`, `imv`, `cmus`, `btop`: one focused application per job.

The configuration deliberately does **not** add a compositor, panel, notification shell,
GUI file manager, or another launcher daemon. Scratchpad-style behavior is kept in the
WM/application workflow rather than introducing a desktop shell.


## v4 workflow and music production

This version targets a 1600x900 T440 display and keeps the desktop intentionally
empty: no bar, no compositor, zero window borders, and moderate floating rectangles.

- `Super+Enter`: normal 90x30 `st`
- `Super+T`: persistent tmux terminal
- `Super+\``: persistent centered scratchpad terminal
- `Super+B`: qutebrowser
- `Super+F`: FL Studio through the dedicated Wine prefix
- `Super+Y`: yazi
- `Super+X`: btop
- `Super+M`: cmus
- `Super+R`: transmission TUI
- `Super+W`: wallpaper/theme picker
- `Super+Shift+Enter`: zoom
- `Super+Shift+Space`: toggle floating

### FL Studio / Bluetooth

Wine and Winetricks are included, but FL Studio itself is not redistributed by nixpkgs.
Install FL Studio into `~/.local/share/wine/flstudio` and launch it with `flstudio`.

Bluetooth headphones are fine for casual listening, arranging and checking mixes, but
they are not the right monitoring device for low-latency recording or playing software
instruments. Use a wired/USB audio path for production. PipeWire is configured with a
128-frame/48 kHz starting point; Bluetooth will still add its own transport latency.

### Generation storage

systemd-boot is limited to three entries: the current generation plus two previous
generations. A weekly trimmer also keeps the system profile at three generations and
runs garbage collection. This is intentionally conservative but keeps the Nix store
from accumulating every rebuild forever.

### Package audit

The core CLI stack used by this config is intentionally small: tmux, fzf, fd,
ripgrep, zoxide, jq, lazygit, yazi, qutebrowser, zathura, cmus, mpv, btop,
fastfetch, feh, and Wine/Winetricks. NixOS's package index currently exposes
these as nixpkgs packages; FL Studio itself is not a nixpkgs package and must
be installed into the Wine prefix separately.

The NixOS package search is the authoritative place to verify the exact package
attribute for the pinned nixpkgs revision.

### Audio rule of thumb

Bluetooth headphones are an output convenience, not the low-latency monitoring path.
For recording vocals/instruments or playing a MIDI keyboard/software instrument, use
wired headphones or a USB audio interface. A2DP Bluetooth adds transport latency that
a PipeWire buffer setting cannot remove.


## v5 audit notes

- Scratchpad lookup uses the `WM_CLASS` instance (`--classname`), matching `st -n scratchpad`.
- qutebrowser, RetroArch and the FL Studio Wine window are intended to float as brutalist rectangles.
- Removed the unsafe/awkward dwm self-restart binding; rebuild/restart X normally after changing dwm.
- `Super+Tab` now cycles focus; `Super+Space` selects the floating layout.
- The repository intentionally does not include a `flake.lock` yet; generate and commit one on the T440 (or another Nix machine) before treating the repo as fully reproducible.
- The `st` Xresources patch still contains `pkgs.lib.fakeHash`; this is the remaining intentional first-build blocker and must be replaced with the real fixed-output hash.
