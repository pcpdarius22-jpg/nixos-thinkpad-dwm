/* dwm config.h — retro/suckless rice for T440
 * Edit this file + `sudo nixos-rebuild switch --flake /etc/nixos#thinkpad` to apply changes.
 * There is no live-reload for dwm itself — that's normal, it's compiled-in by design.
 */

#include <X11/XF86keysym.h>

/* appearance */
static const unsigned int borderpx  = 0;        /* brutalist: no window borders */
static const unsigned int snap      = 32;       /* snap pixel */
static const int showbar            = 0;        /* no status bar */
static const int topbar             = 1;        /* 0 means bottom bar */
static const char *fonts[]          = { "monospace:size=10" };
static const char dmenufont[]       = "monospace:size=10";

/* retro brown/beige palette */
static const char col_bg[]        = "#151210";
static const char col_bg_alt[]    = "#211c18";
static const char col_fg[]        = "#a89680";
static const char col_fg_bright[] = "#e8dcc8";
static const char col_accent[]    = "#c9a876";

static const char *colors[][3] = {
	/*               fg           bg         border   */
	[SchemeNorm] = { col_fg,      col_bg,    col_bg_alt },
	[SchemeSel]  = { col_fg_bright, col_bg_alt, col_accent },
};

/* tagging */
static const char *tags[] = { "1", "2", "3", "4", "5", "6", "7", "8", "9" };

static const Rule rules[] = {
	/* xprop(1): WM_CLASS(STRING) = instance, class; WM_NAME(STRING) = title */
	/* class      instance    title       tags mask     isfloating   monitor */
	{ "mpv",      NULL,       NULL,       0,            1,           -1 },
	{ "qutebrowser", NULL, NULL,     0,            1,           -1 },
	{ "retroarch", NULL, NULL,        0,            1,           -1 },
	{ "FL64.exe", NULL, NULL,         0,            1,           -1 },
	{ "st",       NULL,       NULL,       0,            1,           -1 },
	{ NULL,       "scratchpad", NULL,       0,            1,           -1 },
	{ "Blueman-manager", NULL, NULL,      0,            1,           -1 },
	{ "Nm-connection-editor", NULL, NULL, 0,            1,           -1 },
};

/* layout(s) */
static const float mfact     = 0.55;
static const int nmaster     = 1;
static const int resizehints = 1;
static const int lockfullscreen = 1;

static const Layout layouts[] = {
	/* symbol     arrange function */
	{ "[]=",      tile },
	{ "><>",      NULL },    /* floating */
	{ "[M]",      monocle },
};

/* key definitions */
#define MODKEY Mod4Mask
#define TAGKEYS(KEY,TAG) \
	{ MODKEY,                       KEY,      view,           {.ui = 1 << TAG} }, \
	{ MODKEY|ControlMask,           KEY,      toggleview,     {.ui = 1 << TAG} }, \
	{ MODKEY|ShiftMask,             KEY,      tag,            {.ui = 1 << TAG} }, \
	{ MODKEY|ControlMask|ShiftMask, KEY,      toggletag,      {.ui = 1 << TAG} },

#define SHCMD(cmd) { .v = (const char*[]){ "/bin/sh", "-c", cmd, NULL } }

/* helper for spawning */
static char dmenumon[2] = "0";
static const char *dmenucmd[] = { "dmenu_run", "-m", dmenumon, "-fn", dmenufont,
	"-nb", col_bg, "-nf", col_fg, "-sb", col_accent, "-sf", col_bg, NULL };
static const char *termcmd[]  = { "st", "-g", "90x30", NULL };
static const char *tmuxcmd[] = { "st", "-g", "100x32", "-e", "tmux-session", NULL };

static const Key keys[] = {
	/* modifier                     key        function        argument */
	{ MODKEY,                       XK_Return, spawn,          {.v = termcmd } },
	{ MODKEY,                       XK_t,      spawn,          {.v = tmuxcmd } },
	{ MODKEY,                       XK_grave,  spawn,          SHCMD("scratchpad") },
	{ MODKEY,                       XK_d,      spawn,          {.v = dmenucmd } },
	{ MODKEY,                       XK_q,      killclient,     {0} },
	{ MODKEY|ShiftMask,             XK_e,      quit,           {0} },

	/* apps */
	{ MODKEY,                       XK_b,      spawn,          SHCMD("qutebrowser") },
	{ MODKEY,                       XK_f,      spawn,          SHCMD("flstudio") },
	{ MODKEY|ShiftMask,             XK_b,      spawn,          SHCMD("st -e lynx https://wtr-lab.com") },
	{ MODKEY,                       XK_y,      spawn,          SHCMD("st -g 100x32 -e yazi") },
	{ MODKEY,                       XK_g,      spawn,          SHCMD("retroarch") },
	{ MODKEY,                       XK_x,      spawn,          SHCMD("st -g 90x30 -e btop") },
	{ MODKEY,                       XK_m,      spawn,          SHCMD("st -g 90x24 -e cmus") },
	{ MODKEY,                       XK_r,      spawn,          SHCMD("st -g 100x32 -e tremc") },
	{ MODKEY,                       XK_w,      spawn,          SHCMD("set-wallpaper") },
	{ MODKEY|ShiftMask,             XK_n,      spawn,          SHCMD("nm-connection-editor") },
	{ MODKEY|ShiftMask,             XK_m,      spawn,          SHCMD("blueman-manager") },

	/* focus / layout (dwm stack model, not spatial) */
	{ MODKEY,                       XK_j,      focusstack,     {.i = +1 } },
	{ MODKEY,                       XK_k,      focusstack,     {.i = -1 } },
	{ MODKEY,                       XK_h,      setmfact,       {.f = -0.05} },
	{ MODKEY,                       XK_l,      setmfact,       {.f = +0.05} },
	{ MODKEY|ShiftMask,             XK_Return, zoom,           {0} },
	{ MODKEY|ShiftMask,             XK_space, togglefloating, {0} },
	{ MODKEY,                       XK_Tab,    focusstack,     {.i = +1 } },
	{ MODKEY,                       XK_space,  setlayout,      {.v = &layouts[1] } },
	{ MODKEY,                       XK_0,      view,           {.ui = ~0 } },
	{ MODKEY|ShiftMask,             XK_0,      tag,            {.ui = ~0 } },
	{ MODKEY,                       XK_comma,  focusmon,       {.i = -1 } },
	{ MODKEY,                       XK_period, focusmon,       {.i = +1 } },

	TAGKEYS(XK_1, 0) TAGKEYS(XK_2, 1) TAGKEYS(XK_3, 2)
	TAGKEYS(XK_4, 3) TAGKEYS(XK_5, 4) TAGKEYS(XK_6, 5)
	TAGKEYS(XK_7, 6) TAGKEYS(XK_8, 7) TAGKEYS(XK_9, 8)

	/* media / brightness keys */
	{ 0, XF86XK_AudioRaiseVolume,  spawn, SHCMD("wpctl set-volume @DEFAULT_AUDIO_SINK@ 5%+") },
	{ 0, XF86XK_AudioLowerVolume,  spawn, SHCMD("wpctl set-volume @DEFAULT_AUDIO_SINK@ 5%-") },
	{ 0, XF86XK_AudioMute,         spawn, SHCMD("wpctl set-mute @DEFAULT_AUDIO_SINK@ toggle") },
	{ 0, XF86XK_MonBrightnessUp,   spawn, SHCMD("brightnessctl set +10%") },
	{ 0, XF86XK_MonBrightnessDown, spawn, SHCMD("brightnessctl set 10%-") },
};

/* button definitions */
static const Button buttons[] = {
	/* click                event mask      button          function        argument */
	{ ClkLtSymbol,          0,              Button1,        setlayout,      {0} },
	{ ClkWinTitle,          0,              Button2,        zoom,           {0} },
	{ ClkClientWin,         MODKEY,         Button1,        movemouse,      {0} },
	{ ClkClientWin,         MODKEY,         Button2,        togglefloating, {0} },
	{ ClkClientWin,         MODKEY,         Button3,        resizemouse,    {0} },
	{ ClkTagBar,            0,              Button1,        view,           {0} },
	{ ClkTagBar,            0,              Button3,        toggleview,     {0} },
	{ ClkTagBar,            MODKEY,         Button1,        tag,            {0} },
	{ ClkTagBar,            MODKEY,         Button3,        toggletag,      {0} },
};
