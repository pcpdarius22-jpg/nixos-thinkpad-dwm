/* dmenu config.h — matches dwm's retro palette */
static int topbar = 1;
static const char *fonts[] = { "monospace:size=10" };
static const char *prompt      = NULL;
static const char *colors[SchemeLast][2] = {
	/*                  fg          bg        */
	[SchemeNorm] = { "#a89680", "#151210" },
	[SchemeSel]  = { "#151210", "#c9a876" },
	[SchemeOut]  = { "#151210", "#c9a876" },
};
static unsigned int lines      = 0;
static const char worddelimiters[] = " ";
