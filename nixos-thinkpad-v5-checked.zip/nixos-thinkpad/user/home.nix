{ pkgs, ... }: {
  home.username = "sloth";
  home.homeDirectory = "/home/sloth";

  imports = [ ./apps.nix ./theme.nix ];

  home.packages = with pkgs; [
    # Music production (FL Studio via Wine; REAPER as native fallback)
    winetricks
    reaper       # native fallback DAW, lighter than running everything through Wine
    yt-dlp
    pulsemixer
    sox          # command-line sampling/trimming/resampling

    # Terminal-centric daily drivers
    cmus         # music listening
    mpv          # movies / anime / YouTube playback (hardware-decoded via VAAPI)
    ytfzf        # fzf-driven YouTube search, plays through mpv
    zathura      # vim-keys PDF reader
    lynx         # ultra-light text browser (wtr-lab, etc.)

    # Torrents — fully terminal
    transmission_4
    tremc        # ncurses TUI for transmission-daemon

    # System info & files
    btop
    fastfetch
    feh          # sets the wallpaper (also a fallback light image viewer)
    yazi

    # Retro emulation — RetroArch (rgui menu, see apps.nix) for the systems
    # that run full-speed on this iGPU, standalone emulators for the rest.
    (retroarch.override {
      cores = with libretro; [
        mgba genesis-plus-gx fceumm gambatte snes9x mupen64plus melonds
      ];
    })

    brightnessctl
  ];

  # Auto-start X on the console you land on after autologin — no display manager.
  programs.bash.enable = true;
  programs.bash.profileExtra = ''
    if [ -z "$DISPLAY" ] && [ "$(tty)" = "/dev/tty1" ]; then
      exec startx
    fi
  '';

  programs.home-manager.enable = true;
  home.stateVersion = "24.11";
}
