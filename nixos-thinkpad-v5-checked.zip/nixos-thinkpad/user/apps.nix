{ pkgs, config, ... }:
let
  # st, patched so it re-reads colors/font from ~/.Xresources on `pkill -USR1 st`
  # (this is what lets wallust re-theme your terminal live when you change wallpaper).
  # Source: https://st.suckless.org/patches/xresources-with-reload-signal/
  myst = pkgs.st.overrideAttrs (old: {
    patches = (old.patches or [ ]) ++ [
      (pkgs.fetchpatch {
        url = "https://st.suckless.org/patches/xresources-with-reload-signal/st-xresources-signal-reloading-20220407-ef05519.diff";
        # First build will fail and print the correct hash — paste it in here.
        # See the README's "hash trick" note if this is unfamiliar.
        hash = pkgs.lib.fakeHash;
      })
    ];
  });

  myDmenu = pkgs.dmenu.override {
    conf = builtins.readFile ./suckless/dmenu-config.h;
  };
in
{
  home.packages = [
    pkgs.tmux pkgs.fzf pkgs.fd pkgs.ripgrep pkgs.zoxide pkgs.jq pkgs.lazygit
    pkgs.xdotool pkgs.xorg.xprop
    pkgs.wineWow64Packages.stable pkgs.winetricks
    myst myDmenu pkgs.qutebrowser ];
  home.sessionVariables.TERMINAL = "st";

  # xinitrc: loads the base theme into the X resource database, starts the
  # status bar feed, then hands off to dwm.
  home.file.".xinitrc".text = ''
    #!/bin/sh
    xrdb -merge "$HOME/.Xresources" 2>/dev/null
    exec dwm
  '';
  home.file.".xinitrc".executable = true;

  programs.zathura = {
    enable = true;
    options = {
      selection-clipboard = "clipboard";
      # neutral retro paper tone instead of stark white
      recolor = false;
      default-bg = "#e8dcc8";
      default-fg = "#151210";
    };
  };

  programs.qutebrowser = {
    enable = true;
    keyBindings.normal = {
      "d" = "tab-close";
      "u" = "undo";
    };
    settings = {
      colors.webpage.darkmode.enabled = true;
      tabs.show = "multiple";
      fonts.default_family = "monospace";
      content.javascript.enabled = true; # wtr-lab / tomato need JS
    };
  };

  # RetroArch: rgui text menu (near-zero GPU/RAM cost vs the default XMB menu)
  # — it also happens to match the retro-terminal look you're going for.
  home.file.".config/retroarch/retroarch.cfg".text = ''
    menu_driver = "rgui"
    video_driver = "gl"
    video_threaded = "true"
    video_vsync = "true"
    rgui_show_start_screen = "false"
    savestate_auto_save = "true"
    savestate_auto_load = "true"
  '';

  # Tiny workflow helpers. These are scripts, not daemons.
  home.file.".local/bin/tmux-session".source = ./scripts/tmux-session;
  home.file.".local/bin/wallpaper-menu".source = ./scripts/wallpaper-menu;
  home.file.".local/bin/app-menu".source = ./scripts/app-menu;
  home.file.".local/bin/scratchpad".source = ./scripts/scratchpad;
  home.file.".local/bin/flstudio".source = ./scripts/flstudio;
  home.file.".local/bin/audio-status".source = ./scripts/audio-status;
}
